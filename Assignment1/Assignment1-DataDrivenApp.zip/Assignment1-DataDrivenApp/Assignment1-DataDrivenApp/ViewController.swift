//
//  ViewController.swift
//  Assignment1-DataDrivenApp
//
//  Created by Lucy Rogers on 06/11/2018.
//  Copyright © 2018 uk.ac.u5lr. All rights reserved.
//
//  COMP329 - Mobile Computing
//  Assignment 1 - Data Driven App
//
//	Author: Lucy Rogers
//  Student ID: 201078869
//

import UIKit

class ViewController: UIViewController {
	
	override func viewDidLoad() {
		super.viewDidLoad()
	
	}
}
